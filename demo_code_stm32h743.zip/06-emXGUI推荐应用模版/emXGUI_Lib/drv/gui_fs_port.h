#ifndef __GUI_FS_PORT_H
#define	__GUI_FS_PORT_H

#include	"emXGUI.h"
#include	"gui_drv_cfg.h"



#ifdef __cplusplus
extern "C" {
#endif  
  
BOOL FileSystem_Init(void);

  
#ifdef	__cplusplus
}
#endif
#endif /* __GUI_RESOURCE_PORT_H */
