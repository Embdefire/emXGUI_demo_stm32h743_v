#ifndef _CPUUSAGE_H_
#define _CPUUSAGE_H_


extern uint32_t cpu_usage_get(char* task);

#endif /* _CPUUSAGE_H_ */

